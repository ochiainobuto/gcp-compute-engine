プログラマのためのGoogle Cloud Platform入門
======================

## 第2章 Webアプリケーション実行基盤を構築しよう

本リポジトリは、「プログラマのためのGoogle Cloud Platform入門〜 サービスの全体像からクラウドネイティブアプリケーション構築まで〜」の第2章で使用するサンプルアプリケーションです。


![gcp](http://www.seshop.com/static/images/product/17756/L.png)


***
## 翔泳社 公式サイト
> http://www.shoeisha.co.jp/book/detail/9784798137148
>
